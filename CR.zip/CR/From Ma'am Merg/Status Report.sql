
    DECLARE @SelectedRFPStatuses nvarchar(max)
	DECLARE @SelectedVendors nvarchar(max)
	DECLARE @SelectedDepartments nvarchar(max)
	DECLARE @SelectedAccounts nvarchar(max)
	DECLARE @SelectedCurrencies nvarchar(max)
	DECLARE @SelectedDateFrom nvarchar(max)
	DECLARE @SelectedDateTo nvarchar(max)
	DECLARE @IsAllDeptSelected nvarchar(max)
	DECLARE @IsAllVendorSelected nvarchar(max)
	DECLARE @IsStatusOpen nvarchar(max)
	SET @SelectedRFPStatuses = N'[{"Status":"Completed - Accounting Process"},
{"Status":"Completed - Payment for Release"},
{"Status":"In Progress - Accounting Process"},
{"Status":"In Progress - Payment Process"},
{"Status":"RFP Accepted"},
{"Status":"RFP For Processing"},
{"Status":"RFP For Review"},
{"Status":"RFP Partially Approved"},
{"Status":"RFP Return to Coordinator"},
{"Status":"Completed - Accounting Process"},
{"Status":"Completed - Payment for Release"},
{"Status":"In Progress - Accounting Process"},
{"Status":"In Progress - Payment Process"},
{"Status":"RFP Accepted"},
{"Status":"RFP Cancelled"},
{"Status":"RFP Declined"},
{"Status":"RFP For Processing"},
{"Status":"RFP For Review"},
{"Status":"RFP Partially Approved"},
{"Status":"RFP Return to Coordinator"}
]'
	SET @SelectedVendors = NULL
	SET @SelectedDepartments = NULL
	SET @SelectedAccounts =  N'[{"AccountID":"8"}]'
	SET @SelectedCurrencies =  N'[{"CurrencyCode":"PHP"},{"CurrencyCode":"USD"}]'
	SET @SelectedDateFrom = CAST ('11/02/2023' as date)
	SET @SelectedDateTo = CAST ('12/01/2023' as date)
	SET @IsAllDeptSelected = 'true'
	SET @IsAllVendorSelected = 'true'
	SET @IsStatusOpen = 'true'

	DECLARE @RFPStatusForBR NVARCHAR(MAX) 
	DECLARE @var_where_stmt    NVARCHAR(4000);
	DECLARE @stmt    NVARCHAR(MAX);
	DROP TABLE IF EXISTS #CTE_SOURCE;
	IF (REPLACE(@IsStatusOpen, '"', '') = 'true')
		SET @RFPStatusForBR = STUFF(@SelectedRFPStatuses, LEN(@SelectedRFPStatuses)  , 0, ',{"Status":"RFP Declined"},{"Status":"RFP Cancelled"},{"StatusNULL":"ISNULL"}');
	ELSE
		SET @RFPStatusForBR = @SelectedRFPStatuses;

	
	SELECT * INTO #CTE_SOURCE FROM
	(  
		SELECT * 
		FROM (  
			SELECT  
				 BR.VendorCode
				,BR.Department
				,BR.DepartmentCode  
				,BR.Currency
				,BR.CurrencyCode  
				,MTA.ACCOUNTCODE 
				,BR.AccountId
				,BR.Account
				,BR.TotalAmount  
				,BR.SubmittedDate --select * FROM BillingRequestHDR where id in (312,328,329,330)
				,R.Status as RFPStatus 
				,BR.RequestNo as BRNo
				,BR.BillingNo
				,BR.BillingDate
				,BR.Description as BillingDescription
				,DET.TotalNetOfVAT
				,R.RFPNumber
				,BR.ID as BRID
				,BR.PONum
				,DET.ID as DETID
				,DET.[InvoiceStatus/OR] as ORNo
				,DET.RFANo 
				,'BR' as SOURCE  --,BR.ID,R.ID AS RFPID,br.Status as brStat
				,R.TicketHandler
				,BR.Status as BRStatus
			FROM BillingRequestHDR BR
			LEFT JOIN RFPDetails DET
				ON DET.BRID = BR.ID 
			LEFT JOIN RFP R
				ON R.ID = DET.ParentId  
			LEFT JOIN MT_ACCOUNTS MTA
				ON MTA.SPID = BR.AccountId
			WHERE
			BR.Status NOT IN ('Draft', 'Cancelled','Declined')  
			AND R.Status NOT IN ('Draft', 'RFP Draft') 
			AND  R.Status in 
				(SELECT DISTINCT  * FROM OPENJSON(@RFPStatusForBR) WITH (Status nvarchar(50) '$.Status')  )
				---------------------------------------------------------------------------------------------------
			UNION ALL 
---------------------------------------------------------------------------------------------------
			SELECT  
				R.VendorCode
				,R.Department
				,R.DepartmentCode  
				,R.Currency
				,R.CurrencyCode  
				,R.AccountCode 
				,R.AccountID
				,R.Account 
				,DET.TotalAmount  
				,R.SubmittedDate
				,R.Status as RFPStatus
				,DET.BRNo  
				,DET.BillingNo
				,DET.BillingDate 
				,DET.BillingDescription 
				,DET.TotalNetOfVAT
				,R.RFPNumber
				,DET.BRID
				,DET.PurchaseOrder -- always null
				,DET.ID as DETID
				,DET.[InvoiceStatus/OR] as ORNo
				,DET.RFANo 
				,'RFP' as SOURCE --,'' AS BRID,R.ID AS RFPID,'' as brStat
				,R.TicketHandler
				,'' as BRStatus
			FROM RFP  R
			INNER JOIN RFPDetails DET
				ON DET.ParentId = R.ID
			WHERE IsFromScratch = 1 
			AND Status NOT IN ('Draft', 'RFP Draft')   
			AND  R.Status in 
				(SELECT  DISTINCT * FROM OPENJSON(@SelectedRFPStatuses) WITH (Status nvarchar(50) '$.Status') )
			
		) S
		WHERE SubmittedDate <> '' and  SubmittedDate is not null
	 
	)  SS 

	
IF (REPLACE(@IsAllDeptSelected, '"', '') = 'true') AND (REPLACE(@IsAllVendorSelected, '"', '') = 'true')
	(
		SELECT  
			CTE.RFANo AS RFA, 
			APV.DOC_NO AS APV,
			CLR.DOC_NO AS ClearingNo,
			CLR.CHECKNO AS CheckNo,
			CLR.AMOUNT_DOCUMENT as CheckAmount, 
			ORHDR.ORNo,
			CTE.DepartmentCode, 
			DATEDIFF(DAY, CTE.SubmittedDate, GETDATE()) AS Age, 
			CONVERT(DATE,DATEADD(DAY, cast(v.payment_terms as int), CTE.SubmittedDate),101) AS DueDate,  
			CTE.VendorCode,
			V.Title as Vendor, 
			CTE.BRNo as 'BillingNum', 
			CTE.BillingNo as 'InvoiceNum',
			convert(date,CTE.BillingDate) as 'InvoiceDate', 
			CTE.BillingDescription as 'InvoiceDescription', 
			CTE.Currency,
			convert(date,CTE.SubmittedDate) as 'SubmittedDate',
			CTE.SOURCE,
			CTE.TotalAmount,  
			CTE.TotalNetOfVAT as 'NetAmount',
			CTE.RFPNumber,
			CASE  
				WHEN CTE.BRID = 0 
					THEN PODET.PONum
				WHEN CTE.BRID <> 0
					THEN CTE.PONum
				ELSE NULL
			END AS PONum, 
			CTE.Department,
			CTE.Account,
			CTE.RFPStatus,
			CTE.BRStatus,
			CTE.TicketHandler
		FROM #CTE_SOURCE CTE 
		LEFT JOIN dbo.APV APV 
			ON APV.REF_DOC = CTE.RFPNumber
			and apv.etl_deleted_date is null
			AND APV.ASSIGNMENT = CTE.BillingNo -- ADDED by MERG
		LEFT JOIN dbo.Clearing CLR
			ON CLR.DOC_NO = APV.CLEARING_DOC 
			AND CLR.VENDOR_CODE = APV.VENDOR_CODE -- ADDED by MERG
		LEFT JOIN PO_Details PODET 
			ON PODET.RFPDtlID = CTE.DETID 
		LEFT JOIN OR_HDR ORHDR 
			ON ORHDR.ID = CTE.ORNo
		INNER JOIN Vendors V 
			ON V.VendorCode = CTE.VendorCode 
		WHERE  
		 CTE.AccountId in 
			(SELECT * FROM OPENJSON(@SelectedAccounts) WITH (AccountID nvarchar(50) '$.AccountID')) 
		 AND
		 CTE.CurrencyCode in 
			(SELECT * FROM OPENJSON(@SelectedCurrencies) WITH (CurrencyCode nvarchar(50) '$.CurrencyCode')) 
		AND
		 convert(date,CTE.SubmittedDate) between (REPLACE(@SelectedDateFrom,  '"', '')) AND (REPLACE(@SelectedDateTo,  '"', ''))
	)
	ORDER BY CTE.VendorCode ASC
	--FOR JSON PATH, INCLUDE_NULL_VALUES


	ELSE IF (REPLACE(@IsAllDeptSelected, '"', '') = 'true') AND (REPLACE(@IsAllVendorSelected, '"', '') = 'false')
	(
		SELECT  
			CTE.RFANo AS RFA, 
			APV.DOC_NO AS APV,
			CLR.DOC_NO AS ClearingNo,
			CLR.CHECKNO AS CheckNo,
			CLR.AMOUNT_DOCUMENT as CheckAmount, 
			ORHDR.ORNo,
			CTE.DepartmentCode, 
			DATEDIFF(DAY, CTE.SubmittedDate, GETDATE()) AS Age, 
			CONVERT(DATE,DATEADD(DAY, cast(v.payment_terms as int), CTE.SubmittedDate),101) AS DueDate,  
			CTE.VendorCode,
			V.Title as Vendor, 
			CTE.BRNo as 'BillingNum', 
			CTE.BillingNo as 'InvoiceNum',
			convert(date,CTE.BillingDate) as 'InvoiceDate', 
			CTE.BillingDescription as 'InvoiceDescription', 
			CTE.Currency,
			convert(date,CTE.SubmittedDate) as 'SubmittedDate',
			CTE.SOURCE,
			CTE.TotalAmount,  
			CTE.TotalNetOfVAT as 'NetAmount',
			CTE.RFPNumber,
			CASE  
				WHEN CTE.BRID = 0 
					THEN PODET.PONum
				WHEN CTE.BRID <> 0
					THEN CTE.PONum
				ELSE NULL
			END AS PONum, 
			CTE.Department,
			CTE.Account,
			CTE.RFPStatus,
			CTE.BRStatus,
			CTE.TicketHandler
		FROM #CTE_SOURCE CTE 
		LEFT JOIN dbo.APV APV 
			ON APV.REF_DOC = CTE.RFPNumber and apv.etl_deleted_date is null
			AND APV.ASSIGNMENT = CTE.BillingNo -- ADDED by MERG
		LEFT JOIN dbo.Clearing CLR
			ON CLR.DOC_NO = APV.CLEARING_DOC 
			AND CLR.VENDOR_CODE = APV.VENDOR_CODE -- ADDED by MERG
		LEFT JOIN PO_Details PODET 
			ON PODET.RFPDtlID = CTE.DETID 
		LEFT JOIN OR_HDR ORHDR 
			ON ORHDR.ID = CTE.ORNo
		INNER JOIN Vendors V 
			ON V.VendorCode = CTE.VendorCode 
		 WHERE  
		 CTE.VendorCode in 
			(SELECT * FROM OPENJSON(@SelectedVendors) WITH (VendorCode nvarchar(50) '$.VendorCode')) 
		 AND
		 CTE.AccountId in 
			(SELECT * FROM OPENJSON(@SelectedAccounts) WITH (AccountID nvarchar(50) '$.AccountID'))
		 AND
		 CTE.CurrencyCode  in 
			(SELECT * FROM OPENJSON(@SelectedCurrencies) WITH (CurrencyCode nvarchar(50) '$.CurrencyCode'))
		AND
		 convert(date,CTE.SubmittedDate) between (REPLACE(@SelectedDateFrom,  '"', '')) AND (REPLACE(@SelectedDateTo,  '"', ''))
	)
	ORDER BY CTE.VendorCode ASC
	FOR JSON PATH, INCLUDE_NULL_VALUES

	ELSE IF (REPLACE(@IsAllDeptSelected, '"', '') = 'false') AND (REPLACE(@IsAllVendorSelected, '"', '') = 'true')
	(
		SELECT  
			CTE.RFANo AS RFA, 
			APV.DOC_NO AS APV,
			CLR.DOC_NO AS ClearingNo,
			CLR.CHECKNO AS CheckNo,
			CLR.AMOUNT_DOCUMENT as CheckAmount, 
			ORHDR.ORNo,
			CTE.DepartmentCode, 
			DATEDIFF(DAY, CTE.SubmittedDate, GETDATE()) AS Age, 
			CONVERT(DATE,DATEADD(DAY, cast(v.payment_terms as int), CTE.SubmittedDate),101) AS DueDate,  
			CTE.VendorCode,
			V.Title as Vendor, 
			CTE.BRNo as 'BillingNum', 
			CTE.BillingNo as 'InvoiceNum',
			convert(date,CTE.BillingDate) as 'InvoiceDate', 
			CTE.BillingDescription as 'InvoiceDescription', 
			CTE.Currency,
			convert(date,CTE.SubmittedDate) as 'SubmittedDate',
			CTE.SOURCE,
			CTE.TotalAmount,  
			CTE.TotalNetOfVAT as 'NetAmount',
			CTE.RFPNumber,
			CASE  
				WHEN CTE.BRID = 0 
					THEN PODET.PONum
				WHEN CTE.BRID <> 0
					THEN CTE.PONum
				ELSE NULL
			END AS PONum, 
			CTE.Department,
			CTE.Account,
			CTE.RFPStatus,
			CTE.BRStatus,
			CTE.TicketHandler
		FROM #CTE_SOURCE CTE 
		LEFT JOIN dbo.APV APV 
			ON APV.REF_DOC = CTE.RFPNumber and apv.etl_deleted_date is null
			AND APV.ASSIGNMENT = CTE.BillingNo -- ADDED by MERG
		LEFT JOIN dbo.Clearing CLR
			ON CLR.DOC_NO = APV.CLEARING_DOC 
			AND CLR.VENDOR_CODE = APV.VENDOR_CODE -- ADDED by MERG
		LEFT JOIN PO_Details PODET 
			ON PODET.RFPDtlID = CTE.DETID 
		LEFT JOIN OR_HDR ORHDR 
			ON ORHDR.ID = CTE.ORNo
		INNER JOIN Vendors V 
			ON V.VendorCode = CTE.VendorCode 
		 WHERE  
		 CTE.DepartmentCode in 
			(SELECT * FROM OPENJSON(@SelectedDepartments) WITH (DepartmentCode nvarchar(50) '$.DepartmentCode')) 
		 AND
		 CTE.AccountId in 
			(SELECT * FROM OPENJSON(@SelectedAccounts) WITH (AccountID nvarchar(50) '$.AccountID')) 
		 AND 
		 CTE.CurrencyCode  in 
			(SELECT * FROM OPENJSON(@SelectedCurrencies) WITH (CurrencyCode nvarchar(50) '$.CurrencyCode'	)) 
		AND
		 convert(date,CTE.SubmittedDate) between (REPLACE(@SelectedDateFrom,  '"', '')) AND (REPLACE(@SelectedDateTo,  '"', ''))
	)
	ORDER BY CTE.VendorCode ASC
	FOR JSON PATH, INCLUDE_NULL_VALUES

	ELSE
	(
		SELECT  
			CTE.RFANo AS RFA, 
			APV.DOC_NO AS APV,
			CLR.DOC_NO AS ClearingNo,
			CLR.CHECKNO AS CheckNo,
			CLR.AMOUNT_DOCUMENT as CheckAmount, 
			ORHDR.ORNo,
			CTE.DepartmentCode, 
			DATEDIFF(DAY, CTE.SubmittedDate, GETDATE()) AS Age, 
			CONVERT(DATE,DATEADD(DAY, cast(v.payment_terms as int), CTE.SubmittedDate),101) AS DueDate,  
			CTE.VendorCode,
			V.Title as Vendor, 
			CTE.BRNo as 'BillingNum', 
			CTE.BillingNo as 'InvoiceNum',
			convert(date,CTE.BillingDate) as 'InvoiceDate', 
			CTE.BillingDescription as 'InvoiceDescription', 
			CTE.Currency,
			convert(date,CTE.SubmittedDate) as 'SubmittedDate',
			CTE.SOURCE,
			CTE.TotalAmount,  
			CTE.TotalNetOfVAT as 'NetAmount',
			CTE.RFPNumber,
			CASE  
				WHEN CTE.BRID = 0 
					THEN PODET.PONum
				WHEN CTE.BRID <> 0
					THEN CTE.PONum
				ELSE NULL
			END AS PONum, 
			CTE.Department,
			CTE.Account,
			CTE.RFPStatus,
			CTE.BRStatus,
			CTE.TicketHandler
		FROM #CTE_SOURCE CTE 
		LEFT JOIN dbo.APV APV 
			ON APV.REF_DOC = CTE.RFPNumber and apv.etl_deleted_date is null
			AND APV.ASSIGNMENT = CTE.BillingNo -- ADDED by MERG
		LEFT JOIN dbo.Clearing CLR
			ON CLR.DOC_NO = APV.CLEARING_DOC 
			AND CLR.VENDOR_CODE = APV.VENDOR_CODE -- ADDED by MERG
		LEFT JOIN PO_Details PODET 
			ON PODET.RFPDtlID = CTE.DETID 
		LEFT JOIN OR_HDR ORHDR 
			ON ORHDR.ID = CTE.ORNo
		INNER JOIN Vendors V 
			ON V.VendorCode = CTE.VendorCode 
		 WHERE  
		 CTE.VendorCode in 
			(SELECT * FROM OPENJSON(@SelectedVendors) WITH (VendorCode nvarchar(50) '$.VendorCode')) 
		 AND
		 CTE.DepartmentCode in 
			(SELECT * FROM OPENJSON(@SelectedDepartments) WITH (DepartmentCode nvarchar(50) '$.DepartmentCode')) 
		 AND
		 CTE.AccountId in 
			(SELECT * FROM OPENJSON(@SelectedAccounts) WITH (AccountID nvarchar(50) '$.AccountID')) 
		 AND
		 CTE.CurrencyCode  in 
			 (SELECT * FROM OPENJSON(@SelectedCurrencies) WITH (CurrencyCode nvarchar(50) '$.CurrencyCode'))
		AND
		 convert(date,CTE.SubmittedDate) between (REPLACE(@SelectedDateFrom,  '"', '')) AND (REPLACE(@SelectedDateTo,  '"', ''))
	)
	ORDER BY CTE.VendorCode ASC
	 FOR JSON PATH, INCLUDE_NULL_VALUES

