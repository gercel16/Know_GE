                          SELECT DISTINCT top 500 R.[Status],
                         '3_RFP_Approved' AS ETitle, 'Vendor Portal - Aging Request for Payment Approval' AS ESubject, 
                         'Dear ' + R.[SpecialApprover] + ',<br><br>Ticket ' + R.RFPNumber + ' - ' + R.RFPDescription + ' is due for review/approval on your end.<br><br>You may open the RFP by clicking on this link: <a href="https://allouthub.sharepoint.com/sites/vportalprod/SitePages/RFPDisplay_appge.aspx?pid='
                          + CAST(LT.RFPID AS VARCHAR(10)) + '">' + CAST(LT.RFPID AS VARCHAR(10)) + '</a>' AS EBody, 0 as BRID, '0' AS BRREQNO, '' AS BRDESC, LT.RFPID, R.RFPNumber AS RFPNO, 
                         R.RFPDescription AS RFPDESC, MTS.TITLE AS SUBACCOUNT, R.Account, MTA.SUBACCOUNTID, R.DepartmentCode, LT.Department, LT.VendorCode, MTA.[3_RFP_APPROVED] AS LEADTIME, 
                         LT.[3_RFP_Approved] AS DAYS_TAKEN, CPD_8.Email AS ERecipient, MTA.TOTALDAYS
FROM            MT_ACTIVITY_LEAD_TIME AS MTA 
INNER JOIN MT_SUBACCOUNTS AS MTS ON MTS.ID = MTA.SUBACCOUNTID AND MTS.etl_deleted_date IS NULL 
INNER JOIN vwLeadTime AS LT ON LT.SubAccount = MTS.TITLE AND CAST(MTA.[3_RFP_APPROVED] AS decimal(4, 1)) < LT.[3_RFP_Approved] 
LEFT OUTER JOIN RFP AS R ON R.ID = LT.RFPID
LEFT OUTER JOIN BillingRequestHDR AS BR ON BR.ID = LT.BRID  
INNER JOIN (SELECT DISTINCT Title,email FROM RFPApproverUsers innerAU
INNER JOIN SPUsers AS spu ON TRIM(UPPER(spu.email)) = TRIM(UPPER(innerAU.Username))) CPD_8 ON R.SpecialApprover= CPD_8.Title
INNER JOIN Vendors ON R.VendorCode = Vendors.VendorCode AND MTA.TOTALDAYS = Vendors.PAYMENT_TERMS
WHERE   (MTA.etl_deleted_date IS NULL) 
AND (LT.RFPForReviewPartialReturnDate IS NOT NULL OR LT.RFPForReviewPartialReturnDate <> '1900-01-01 00:00:00.0000000') 
AND (LT.RFPForProcessingDate IS NULL) 
AND (MTA.[3_RFP_APPROVED] <> '0') 
AND (MTA.[3_RFP_APPROVED] IS NOT NULL) 
AND R.ApprovedByApproverGroup = 1 
AND R.SpecialApproverStage <> 0 
AND R.ApprovedBySpecialApprovers = 0
AND TRIM(R.SpecialApprover) <> '' AND SpecialApprover IS NOT NULL 
AND R.[Status] = 'RFP partially approved'



